#ifndef GENERAL_H
#define GENERAL_H

#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

#endif // GENERAL_H
