#ifndef GENERAL_H
#define GENERAL_H

#include <vector>
#include <iostream>
#include <math.h>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;

#endif // GENERAL_H
